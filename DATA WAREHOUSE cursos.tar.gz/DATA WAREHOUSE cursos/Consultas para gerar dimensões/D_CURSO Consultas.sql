SELECT cs.id AS "ID-CURSO-OLTP", cs.nome AS "NOME-CURSO", ct.nome AS "CATEGORIA-CURSO"
FROM curso AS cs
INNER JOIN categoria AS ct
ON cs.categoria_id = ct.id;