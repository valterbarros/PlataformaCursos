 SELECT id AS 'ID-ALUNO-OLTP', cidade AS 'CIDADE', estado AS 'REGIAO'
 FROM aluno;
 
 