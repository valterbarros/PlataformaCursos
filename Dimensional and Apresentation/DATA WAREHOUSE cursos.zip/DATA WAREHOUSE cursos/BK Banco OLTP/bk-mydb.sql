-- MySQL dump 10.13  Distrib 5.7.12, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: mydb
-- ------------------------------------------------------
-- Server version	5.7.12-0ubuntu1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `F_ACESSO`
--

DROP TABLE IF EXISTS `F_ACESSO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `F_ACESSO` (
  `Data Matrícula` datetime DEFAULT NULL,
  `ID Aluno` int(11) DEFAULT NULL,
  `Estado` varchar(2) DEFAULT NULL,
  `ID Curso` int(11) DEFAULT NULL,
  `ID-PERFIL` int(11) DEFAULT NULL,
  `CURSO-ID` int(11) DEFAULT NULL,
  `DATA_MAT` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `F_ACESSO`
--

LOCK TABLES `F_ACESSO` WRITE;
/*!40000 ALTER TABLE `F_ACESSO` DISABLE KEYS */;
INSERT INTO `F_ACESSO` VALUES ('2010-09-16 00:00:00',36,'DL',1,36,1,NULL),('2007-04-09 00:00:00',85,'MM',1,85,1,NULL),('2014-05-21 00:00:00',85,'MM',1,85,1,NULL),('2013-07-13 00:00:00',72,'KR',1,72,1,NULL),('2015-02-19 00:00:00',19,'FU',1,19,1,NULL),('2006-09-22 00:00:00',19,'FU',1,19,1,NULL),('2008-05-03 00:00:00',59,'WA',1,59,1,NULL),('2014-05-24 00:00:00',34,'ZW',1,34,1,NULL),('2014-03-18 00:00:00',82,'CZ',1,82,1,NULL),('2006-09-19 00:00:00',23,'MS',1,23,1,NULL),('2008-08-12 00:00:00',18,'CG',4,18,4,NULL),('2007-06-10 00:00:00',59,'WA',5,59,5,NULL),('2009-09-21 00:00:00',29,'GG',5,29,5,NULL),('2010-10-28 00:00:00',55,'GT',5,55,5,NULL),('2013-04-23 00:00:00',23,'MS',5,23,5,NULL),('2010-07-24 00:00:00',6,'HE',5,6,5,NULL),('2007-08-13 00:00:00',51,'AD',5,51,5,NULL),('2008-10-16 00:00:00',48,'NT',5,48,5,NULL),('2011-11-17 00:00:00',88,'SD',5,88,5,NULL),('2015-11-11 00:00:00',78,'ZN',5,78,5,NULL),('2012-11-18 00:00:00',57,'FJ',5,57,5,NULL),('2009-12-15 00:00:00',80,'MW',5,80,5,NULL),('2007-06-08 00:00:00',12,'AK',5,12,5,NULL),('2008-02-28 00:00:00',33,'BD',5,33,5,NULL),('2008-09-17 00:00:00',7,'UH',5,7,5,NULL),('2014-06-21 00:00:00',36,'DL',10,36,10,NULL),('2012-05-08 00:00:00',61,'ME',10,61,10,NULL),('2006-08-14 00:00:00',41,'XP',10,41,10,NULL),('2008-02-08 00:00:00',13,'WG',10,13,10,NULL),('2013-06-09 00:00:00',41,'XP',10,41,10,NULL),('2013-09-21 00:00:00',8,'GK',10,8,10,NULL),('2006-07-21 00:00:00',80,'MW',10,80,10,NULL),('2012-10-17 00:00:00',17,'CT',14,17,14,NULL),('2012-02-17 00:00:00',17,'CT',14,17,14,NULL),('2013-11-03 00:00:00',65,'XH',14,65,14,NULL),('2007-09-09 00:00:00',1,'II',14,1,14,NULL),('2014-03-24 00:00:00',22,'YH',14,22,14,NULL),('2011-05-26 00:00:00',32,'TY',14,32,14,NULL),('2007-05-24 00:00:00',56,'NG',14,56,14,NULL),('2013-06-18 00:00:00',6,'HE',14,6,14,NULL),('2014-04-18 00:00:00',30,'ZI',2,30,2,NULL),('2011-12-18 00:00:00',73,'OE',2,73,2,NULL),('2011-04-13 00:00:00',21,'JM',2,21,2,NULL),('2009-05-13 00:00:00',60,'PV',2,60,2,NULL),('2006-03-27 00:00:00',42,'DS',6,42,6,NULL),('2013-10-17 00:00:00',20,'KD',6,20,6,NULL),('2015-08-24 00:00:00',36,'DL',6,36,6,NULL),('2014-05-28 00:00:00',14,'GP',6,14,6,NULL),('2010-05-21 00:00:00',44,'WT',6,44,6,NULL),('2006-10-12 00:00:00',59,'WA',6,59,6,NULL),('2006-01-19 00:00:00',10,'LO',8,10,8,NULL),('2009-11-15 00:00:00',83,'XZ',8,83,8,NULL),('2009-09-02 00:00:00',51,'AD',8,51,8,NULL),('2008-10-25 00:00:00',51,'AD',8,51,8,NULL),('2012-05-24 00:00:00',57,'FJ',8,57,8,NULL),('2009-10-10 00:00:00',90,'BG',8,90,8,NULL),('2012-08-17 00:00:00',71,'SD',8,71,8,NULL),('2015-02-28 00:00:00',77,'XO',8,77,8,NULL),('2012-01-09 00:00:00',84,'HS',8,84,8,NULL),('2011-10-17 00:00:00',29,'GG',8,29,8,NULL),('2013-07-20 00:00:00',18,'CG',11,18,11,NULL),('2008-01-15 00:00:00',49,'VW',11,49,11,NULL),('2007-01-04 00:00:00',40,'SP',11,40,11,NULL),('2008-07-27 00:00:00',83,'XZ',11,83,11,NULL),('2008-12-20 00:00:00',72,'KR',11,72,11,NULL),('2012-06-18 00:00:00',40,'SP',11,40,11,NULL),('2013-07-15 00:00:00',85,'MM',11,85,11,NULL),('2014-09-09 00:00:00',9,'LS',11,9,11,NULL),('2011-04-18 00:00:00',64,'PK',11,64,11,NULL),('2009-12-25 00:00:00',81,'KS',11,81,11,NULL),('2006-05-06 00:00:00',62,'HR',3,62,3,NULL),('2009-10-20 00:00:00',19,'FU',3,19,3,NULL),('2012-01-10 00:00:00',52,'SM',3,52,3,NULL),('2012-12-25 00:00:00',55,'GT',3,55,3,NULL),('2006-02-07 00:00:00',81,'KS',3,81,3,NULL),('2010-07-12 00:00:00',7,'UH',3,7,3,NULL),('2014-08-14 00:00:00',25,'CJ',3,25,3,NULL),('2006-01-16 00:00:00',60,'PV',3,60,3,NULL),('2010-07-18 00:00:00',76,'YW',3,76,3,NULL),('2012-02-18 00:00:00',79,'YK',7,79,7,NULL),('2013-03-12 00:00:00',86,'OD',7,86,7,NULL),('2014-08-03 00:00:00',77,'XO',7,77,7,NULL),('2011-04-25 00:00:00',86,'OD',7,86,7,NULL),('2012-11-09 00:00:00',68,'EZ',7,68,7,NULL),('2009-04-26 00:00:00',81,'KS',7,81,7,NULL),('2015-08-24 00:00:00',56,'NG',7,56,7,NULL),('2014-11-13 00:00:00',17,'CT',7,17,7,NULL),('2006-04-05 00:00:00',67,'QR',7,67,7,NULL),('2014-11-25 00:00:00',27,'ZA',7,27,7,NULL),('2015-02-06 00:00:00',17,'CT',9,17,9,NULL),('2008-05-18 00:00:00',83,'XZ',9,83,9,NULL),('2007-08-09 00:00:00',4,'AM',9,4,9,NULL),('2015-07-17 00:00:00',46,'EX',9,46,9,NULL),('2007-12-27 00:00:00',50,'EY',9,50,9,NULL),('2014-08-01 00:00:00',82,'CZ',9,82,9,NULL),('2013-07-21 00:00:00',83,'XZ',9,83,9,NULL),('2014-07-20 00:00:00',52,'SM',9,52,9,NULL),('2013-10-04 00:00:00',81,'KS',9,81,9,NULL),('2014-09-17 00:00:00',22,'YH',12,22,12,NULL),('2008-08-01 00:00:00',2,'HI',12,2,12,NULL),('2012-12-14 00:00:00',74,'LV',12,74,12,NULL),('2011-07-01 00:00:00',34,'ZW',12,34,12,NULL),('2011-05-22 00:00:00',46,'EX',12,46,12,NULL),('2007-03-06 00:00:00',34,'ZW',12,34,12,NULL),('2006-06-09 00:00:00',44,'WT',12,44,12,NULL),('2006-12-23 00:00:00',29,'GG',12,29,12,NULL),('2010-11-25 00:00:00',73,'OE',12,73,12,NULL),('2013-06-02 00:00:00',53,'UA',12,53,12,NULL),('2007-06-11 00:00:00',37,'LP',12,37,12,NULL),('2006-01-22 00:00:00',40,'SP',12,40,12,NULL),('2006-04-20 00:00:00',52,'SM',13,52,13,NULL),('2009-08-02 00:00:00',13,'WG',13,13,13,NULL),('2012-11-02 00:00:00',14,'GP',13,14,13,NULL),('2015-11-07 00:00:00',87,'KI',13,87,13,NULL),('2013-02-26 00:00:00',23,'MS',13,23,13,NULL),('2014-10-21 00:00:00',54,'XT',13,54,13,NULL),('2014-02-15 00:00:00',58,'ZT',13,58,13,NULL),('2010-04-25 00:00:00',59,'WA',13,59,13,NULL),('2009-02-16 00:00:00',77,'XO',13,77,13,NULL),('2010-10-11 00:00:00',36,'DL',13,36,13,NULL);
/*!40000 ALTER TABLE `F_ACESSO` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `administrador`
--

DROP TABLE IF EXISTS `administrador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `administrador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(45) NOT NULL,
  `senha` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrador`
--

LOCK TABLES `administrador` WRITE;
/*!40000 ALTER TABLE `administrador` DISABLE KEYS */;
INSERT INTO `administrador` VALUES (1,'paulo','123456'),(2,'jones','123456'),(3,'valter','123456');
/*!40000 ALTER TABLE `administrador` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aluno`
--

DROP TABLE IF EXISTS `aluno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aluno` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(145) NOT NULL,
  `login` varchar(45) NOT NULL,
  `senha` varchar(45) NOT NULL,
  `carteira` decimal(10,0) NOT NULL DEFAULT '0',
  `cidade` varchar(45) NOT NULL,
  `estado` varchar(2) NOT NULL,
  `data_nascimento` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aluno`
--

LOCK TABLES `aluno` WRITE;
/*!40000 ALTER TABLE `aluno` DISABLE KEYS */;
INSERT INTO `aluno` VALUES (1,'Eric Mercer','Wyoming','LTZ18UOB3KX',108,'Recife','PE','1949-02-18 22:57:28'),(2,'Jarrod Mccarthy','Selma','SYV28GPH0ZA',17,'Maceió','AL','1982-09-16 08:38:35'),(3,'Rigel Farley','Karly','INI82JYX5LD',82,'Arapiraca','AL','1971-03-05 23:30:32'),(4,'Jaquelyn Levine','Florence','AHR12FOO6AI',99,'Rio Branco','AC','1985-02-16 18:05:31'),(5,'Sophia Mathis','Deanna','XDR10LRP0FO',49,'Cabrobó','PE','1960-02-28 14:52:55'),(6,'Ali Henderson','Benjamin','RDN01IYX9NF',1,'São Paulo','SP','1950-06-02 16:10:43'),(7,'Aiko Ferguson','Slade','JFU98XNK5DO',90,'Rio de Janeiro','RJ','1986-10-16 17:02:03'),(8,'Aubrey Dalton','Uma','CHE37DCX3JC',60,'Porto Real','RJ','2001-12-07 15:33:54'),(9,'Melanie Barnes','Adara','LSX12SNM1CY',101,'Macaé','RJ','2006-07-30 18:52:53'),(10,'Eaton Wilcox','Iona','NQT52IBG5MO',2,'Guarulhos','SP','1969-10-13 21:42:21'),(11,'Thor Stephens','Germaine','MOG37IXR9RT',10,'Recife','PE','1985-01-09 21:36:07'),(12,'Tamekah Miranda','Regan','FAB37NEC9XI',85,'Maceió','AL','1950-08-10 08:57:37'),(13,'Perry Trujillo','Bree','HHQ12WAD7PK',70,'Arapiraca','AL','1974-10-01 21:25:25'),(14,'Raja Medina','Mechelle','XGW02APU5TT',105,'Rio Branco','AC','2004-09-13 19:16:22'),(15,'Jada Hays','Gil','UFP48RCF3FV',108,'Cabrobó','PE','1974-02-11 20:41:26'),(16,'Amy Conway','Yuli','NDN07IHW7GL',12,'São Paulo','SP','1967-01-17 06:15:56'),(17,'Cheyenne Mitchell','Jack','MAH56EBL8PL',105,'Rio de Janeiro','RJ','1989-07-05 20:29:25'),(18,'Jillian Giles','Haley','JAF52YCY2NW',19,'Porto Real','RJ','1998-01-07 04:30:10'),(19,'Jonah Lucas','Skyler','SFA35ONL0EN',79,'Macaé','RJ','1979-07-14 07:09:11'),(20,'Beck Barton','Cody','MIK33GSV6FE',17,'Guarulhos','SP','1983-11-10 03:37:33'),(21,'Dahlia Estes','Erasmus','PXT10TXA1MJ',95,'Recife','PE','1997-08-03 07:15:59'),(22,'Jonas Mcpherson','Kennedy','DKH51KDB6IP',71,'Maceió','AL','1958-12-08 13:42:59'),(23,'Meghan Bullock','Brady','XZI61DSO5LF',27,'Arapiraca','AL','1987-10-10 18:55:25'),(24,'Basia Rivera','Wing','DKA81IBE4CU',14,'Rio Branco','AC','2003-01-12 04:55:40'),(25,'Gage Sanford','Griffin','BQP98EPN6YA',53,'Cabrobó','PE','1952-12-05 00:58:01'),(26,'Madison Cantu','Ingrid','GFN30MHR7FZ',54,'São Paulo','SP','1961-06-19 07:30:35'),(27,'Nissim Todd','Logan','KWH44NCS2HN',85,'Rio de Janeiro','RJ','1947-12-27 23:29:56'),(28,'Darryl Cabrera','Colton','HYJ85RJF4FW',43,'Porto Real','RJ','1971-03-20 18:52:11'),(29,'Quinn Brock','Laura','HJQ66FVS9LN',61,'Macaé','RJ','2001-05-01 12:40:46'),(30,'Joan Ballard','Angelica','NRS10FOS7YF',102,'Guarulhos','SP','1978-08-04 02:07:09'),(31,'Sydnee Chapman','Audra','JHZ29XVD7ZZ',56,'Recife','PE','1973-01-25 11:37:22'),(32,'Derek Langley','Bert','AMJ09VIP9PA',4,'Maceió','AL','2001-03-29 15:46:34'),(33,'Neil Newton','Aurora','IEN29XXB9PA',116,'Arapiraca','AL','1994-02-22 10:26:52'),(34,'Jana Hess','Quemby','NHN94KXM0MU',83,'Rio Branco','AC','1994-01-07 03:53:35'),(35,'Leslie Forbes','Jenna','LEX55MSV6WL',93,'Cabrobó','PE','2004-05-19 02:00:27'),(36,'Velma Fox','Fredericka','TLR28HID5YG',68,'São Paulo','SP','1969-08-20 09:09:04'),(37,'Audra Gibson','Blake','LYE01UFQ3HG',72,'Rio de Janeiro','RJ','1966-03-11 16:09:42'),(38,'Dakota Vaughn','Nero','KQD20AOJ7AS',102,'Porto Real','RJ','2006-09-19 08:35:02'),(39,'Pearl Stone','Martena','HWB90TOA3NN',26,'Macaé','RJ','2002-10-31 04:38:21'),(40,'Damon Branch','Aristotle','RCJ13INQ3RS',73,'Guarulhos','SP','1949-09-15 09:01:02'),(41,'Kiara Wolfe','Farrah','CWY80VMN1ZA',87,'Recife','PE','1946-11-26 15:27:47'),(42,'Grady Hart','Rajah','MPW07JLS1GV',109,'Maceió','AL','1948-06-23 15:59:30'),(43,'Garth Velazquez','Charles','SBD24RPP3LF',108,'Arapiraca','AL','2006-07-04 03:27:29'),(44,'Nicholas Turner','Kristen','ACK36KPD3QW',67,'Rio Branco','AC','1988-06-05 13:42:01'),(45,'Emery Joyner','Sylvia','SAJ32SFI6UU',58,'Cabrobó','PE','1974-05-28 06:37:26'),(46,'Michelle Gay','Hoyt','BDN56WNI5KI',59,'São Paulo','SP','1971-08-15 07:31:21'),(47,'Wallace Allison','Lacota','LIW73VOU3MW',119,'Rio de Janeiro','RJ','1993-05-22 15:57:32'),(48,'Wyoming Flores','Carl','OGD81HTX3OV',85,'Porto Real','RJ','1991-11-23 15:12:10'),(49,'Kuame Albert','Sylvia','SIL83SKD2PZ',26,'Macaé','RJ','2008-06-30 06:11:09'),(50,'Sawyer Mcintyre','Gwendolyn','JHX76DMN8BH',68,'Guarulhos','SP','2008-07-15 22:51:09'),(51,'Norman Cooper','Deborah','AJJ75VIA6UB',72,'Recife','PE','2001-05-01 00:47:34'),(52,'Felicia Riddle','Hasad','BXY30TMU1UE',6,'Maceió','AL','1945-08-19 09:23:38'),(53,'Dominic Anderson','Mira','YOI16LDE6RC',32,'Arapiraca','AL','1949-10-31 10:52:32'),(54,'Frances Webb','Wade','ZKL58LPJ7ML',10,'Rio Branco','AC','1948-09-06 14:31:52'),(55,'Tobias Robertson','Reece','HIN18EYW2NZ',22,'Cabrobó','PE','1982-12-21 20:45:57'),(56,'Brenna Joyce','Doris','ERS18WSY6QK',34,'São Paulo','SP','1945-12-25 05:48:30'),(57,'Rana Slater','Tarik','YUT20ETB2DU',14,'Rio de Janeiro','RJ','1959-09-13 05:41:46'),(58,'Orli Kelley','Mohammad','RJC92BFH7KE',102,'Porto Real','RJ','1948-09-16 10:29:12'),(59,'Wing Mcdaniel','Michelle','UMI38HLX0NA',111,'Macaé','RJ','1983-07-25 18:59:23'),(60,'Gwendolyn Larson','Zephr','XAB11LCA0PP',43,'Guarulhos','SP','2006-08-25 12:59:27'),(61,'Iona Leon','Erich','HSO42IRD3QT',24,'Recife','PE','1963-05-02 02:28:30'),(62,'Vera Dale','Hiroko','LJW27GPK1BB',34,'Maceió','AL','1972-01-28 22:07:47'),(63,'Yetta Mcclure','Jack','EYM01TVV0TO',101,'Arapiraca','AL','2008-07-04 11:37:39'),(64,'Amos Wolf','May','LBO03BQK8RQ',87,'Rio Branco','AC','1987-09-18 18:51:40'),(65,'Ezra Hyde','Zia','GFN22BSV2IR',107,'Cabrobó','PE','1990-10-20 00:22:48'),(66,'Ivory Howe','Beau','AYB51CUK7UR',49,'São Paulo','SP','1978-03-26 11:44:37'),(67,'Alfonso Anthony','Mollie','RQL47ZIY2OT',86,'Rio de Janeiro','RJ','1981-05-25 17:17:12'),(68,'Amena Mason','Bevis','CJU31KUA3VG',51,'Porto Real','RJ','1984-11-21 03:20:32'),(69,'Cheyenne Smith','Colleen','GDA81BJF7YB',63,'Macaé','RJ','1976-05-13 15:08:26'),(70,'Cain Stevenson','Kellie','CVK88KRF7BT',90,'Guarulhos','SP','1997-09-11 22:44:32'),(71,'Oliver Bolton','Colby','XQZ16NUO6FJ',63,'Recife','PE','1986-08-25 20:16:53'),(72,'Erin Newton','Howard','KDF88AIJ4BO',84,'Maceió','AL','1975-07-10 21:02:51'),(73,'Slade Dudley','Leigh','ITB89QRO1KT',89,'Arapiraca','AL','1968-06-09 13:45:07'),(74,'Phillip Vasquez','Branden','VEH33JEF8RY',48,'Rio Branco','AC','1950-10-17 20:29:54'),(75,'Perry Martin','Veda','YFJ24GFZ9TQ',36,'Cabrobó','PE','1994-08-13 15:18:03'),(76,'Chaney Murray','Ciara','SRI28RZM4UO',1,'São Paulo','SP','1969-06-16 18:50:34'),(77,'Perry Carlson','Aspen','TFG38CZW3CL',42,'Rio de Janeiro','RJ','1958-12-02 14:15:13'),(78,'Nevada Mcmahon','Courtney','DJQ50COA7UK',115,'Porto Real','RJ','1947-03-30 19:13:26'),(79,'Kirsten Estes','Althea','GGS14RMX7TA',30,'Macaé','RJ','1999-12-27 17:04:44'),(80,'Magee Landry','Karleigh','AKY42TJN9ZY',33,'Guarulhos','SP','1983-08-30 17:52:36'),(81,'Savannah Peck','Kareem','VYJ99SID8KZ',78,'Recife','PE','1950-04-13 17:15:10'),(82,'Adam Willis','Imelda','WKP65LBB3SG',9,'Maceió','AL','1972-06-25 07:10:00'),(83,'Amanda Dixon','Bertha','VYE08ADD3PW',74,'Arapiraca','AL','1959-07-26 03:29:44'),(84,'Oleg Cain','Carl','XQJ80BDG1KS',64,'Rio Branco','AC','1954-06-25 14:58:47'),(85,'Leilani Rasmussen','Randall','BHS11TDR5PT',18,'Cabrobó','PE','2001-05-01 14:33:20'),(86,'Ava Yang','Regina','HJS70TEZ3ZQ',47,'São Paulo','SP','1967-11-02 00:58:30'),(87,'Willa Rogers','Amena','AUF55ZCZ2DB',28,'Rio de Janeiro','RJ','1996-10-28 11:08:27'),(88,'Jacob Weiss','Uriah','VKU70QUH9YX',78,'Porto Real','RJ','1989-02-13 08:17:28'),(89,'Avram Carter','David','OAO61DSZ7JZ',24,'Macaé','RJ','1994-12-23 10:43:49'),(90,'Kirsten Leblanc','Gabriel','HBP04GJG2RJ',104,'Guarulhos','SP','1946-03-30 11:12:42');
/*!40000 ALTER TABLE `aluno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categoria`
--

DROP TABLE IF EXISTS `categoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categoria` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categoria`
--

LOCK TABLES `categoria` WRITE;
/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` VALUES (1,'Programação'),(2,'Utilidade Pública'),(3,'Idioma');
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conteudo`
--

DROP TABLE IF EXISTS `conteudo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conteudo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_id` int(11) NOT NULL,
  `conteudo` varchar(45) NOT NULL,
  `curso_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_conteudo_tipo1_idx` (`tipo_id`),
  KEY `fk_conteudo_curso1_idx` (`curso_id`),
  CONSTRAINT `fk_conteudo_curso1` FOREIGN KEY (`curso_id`) REFERENCES `curso` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_conteudo_tipo1` FOREIGN KEY (`tipo_id`) REFERENCES `tipo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=211 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conteudo`
--

LOCK TABLES `conteudo` WRITE;
/*!40000 ALTER TABLE `conteudo` DISABLE KEYS */;
INSERT INTO `conteudo` VALUES (1,1,'Aula 1',1),(2,1,'Aula 2',1),(3,1,'Aula 3',1),(4,1,'Aula 4',1),(5,1,'Aula 5',1),(6,2,'Leitura 1',1),(7,2,'Leitura 2',1),(8,2,'Leitura 3',1),(9,3,'Exercício 1',1),(10,3,'Exercício 2',1),(11,3,'Exercício 3',1),(12,3,'Exercício 4',1),(13,4,'Teste de Satisfação 1',1),(14,4,'Teste de Satisfação 2',1),(15,5,'Teste Final',1),(16,1,'Aula 1',2),(17,1,'Aula 2',2),(18,1,'Aula 3',2),(19,1,'Aula 4',2),(20,1,'Aula 5',2),(21,2,'Leitura 1',2),(22,2,'Leitura 2',2),(23,2,'Leitura 3',2),(24,3,'Exercício 1',2),(25,3,'Exercício 2',2),(26,3,'Exercício 3',2),(27,3,'Exercício 4',2),(28,4,'Teste de Satisfação 1',2),(29,4,'Teste de Satisfação 2',2),(30,5,'Teste Final',2),(31,1,'Aula 1',3),(32,1,'Aula 2',3),(33,1,'Aula 3',3),(34,1,'Aula 4',3),(35,1,'Aula 5',3),(36,2,'Leitura 1',3),(37,2,'Leitura 2',3),(38,2,'Leitura 3',3),(39,3,'Exercício 1',3),(40,3,'Exercício 2',3),(41,3,'Exercício 3',3),(42,3,'Exercício 4',3),(43,4,'Teste de Satisfação 1',3),(44,4,'Teste de Satisfação 2',3),(45,5,'Teste Final',3),(46,1,'Aula 1',4),(47,1,'Aula 2',4),(48,1,'Aula 3',4),(49,1,'Aula 4',4),(50,1,'Aula 5',4),(51,2,'Leitura 1',4),(52,2,'Leitura 2',4),(53,2,'Leitura 3',4),(54,3,'Exercício 1',4),(55,3,'Exercício 2',4),(56,3,'Exercício 3',4),(57,3,'Exercício 4',4),(58,4,'Teste de Satisfação 1',1),(59,4,'Teste de Satisfação 2',4),(60,5,'Teste Final',4),(61,1,'Aula 1',5),(62,1,'Aula 2',5),(63,1,'Aula 3',5),(64,1,'Aula 4',5),(65,1,'Aula 5',5),(66,2,'Leitura 1',5),(67,2,'Leitura 2',5),(68,2,'Leitura 3',5),(69,3,'Exercício 1',5),(70,3,'Exercício 2',5),(71,3,'Exercício 3',5),(72,3,'Exercício 4',5),(73,4,'Teste de Satisfação 1',5),(74,4,'Teste de Satisfação 2',5),(75,5,'Teste Final',5),(76,1,'Aula 1',6),(77,1,'Aula 2',6),(78,1,'Aula 3',6),(79,1,'Aula 4',6),(80,1,'Aula 5',6),(81,2,'Leitura 1',6),(82,2,'Leitura 2',6),(83,2,'Leitura 3',6),(84,3,'Exercício 1',6),(85,3,'Exercício 2',6),(86,3,'Exercício 3',6),(87,3,'Exercício 4',6),(88,4,'Teste de Satisfação 1',6),(89,4,'Teste de Satisfação 2',6),(90,5,'Teste Final',6),(91,1,'Aula 1',7),(92,1,'Aula 2',7),(93,1,'Aula 3',1),(94,1,'Aula 4',7),(95,1,'Aula 5',7),(96,2,'Leitura 1',7),(97,2,'Leitura 2',7),(98,2,'Leitura 3',7),(99,3,'Exercício 1',7),(100,3,'Exercício 2',7),(101,3,'Exercício 3',7),(102,3,'Exercício 4',7),(103,4,'Teste de Satisfação 1',7),(104,4,'Teste de Satisfação 2',7),(105,5,'Teste Final',7),(106,1,'Aula 1',8),(107,1,'Aula 2',8),(108,1,'Aula 3',8),(109,1,'Aula 4',8),(110,1,'Aula 5',8),(111,2,'Leitura 1',8),(112,2,'Leitura 2',8),(113,2,'Leitura 3',8),(114,3,'Exercício 1',8),(115,3,'Exercício 2',8),(116,3,'Exercício 3',8),(117,3,'Exercício 4',8),(118,4,'Teste de Satisfação 1',8),(119,4,'Teste de Satisfação 2',8),(120,5,'Teste Final',8),(121,1,'Aula 1',9),(122,1,'Aula 2',9),(123,1,'Aula 3',9),(124,1,'Aula 4',9),(125,1,'Aula 5',9),(126,2,'Leitura 1',9),(127,2,'Leitura 2',9),(128,2,'Leitura 3',9),(129,3,'Exercício 1',9),(130,3,'Exercício 2',9),(131,3,'Exercício 3',9),(132,3,'Exercício 4',9),(133,4,'Teste de Satisfação 1',9),(134,4,'Teste de Satisfação 2',9),(135,5,'Teste Final',9),(136,1,'Aula 1',10),(137,1,'Aula 2',10),(138,1,'Aula 3',10),(139,1,'Aula 4',10),(140,1,'Aula 5',10),(141,2,'Leitura 1',10),(142,2,'Leitura 2',10),(143,2,'Leitura 3',10),(144,3,'Exercício 1',10),(145,3,'Exercício 2',10),(146,3,'Exercício 3',10),(147,3,'Exercício 4',10),(148,4,'Teste de Satisfação 1',10),(149,4,'Teste de Satisfação 2',10),(150,5,'Teste Final',10),(151,1,'Aula 1',11),(152,1,'Aula 2',11),(153,1,'Aula 3',11),(154,1,'Aula 4',11),(155,1,'Aula 5',11),(156,2,'Leitura 1',11),(157,2,'Leitura 2',11),(158,2,'Leitura 3',11),(159,3,'Exercício 1',11),(160,3,'Exercício 2',11),(161,3,'Exercício 3',11),(162,3,'Exercício 4',11),(163,4,'Teste de Satisfação 1',11),(164,4,'Teste de Satisfação 2',11),(165,5,'Teste Final',11),(166,1,'Aula 1',12),(167,1,'Aula 2',12),(168,1,'Aula 3',12),(169,1,'Aula 4',12),(170,1,'Aula 5',12),(171,2,'Leitura 1',12),(172,2,'Leitura 2',12),(173,2,'Leitura 3',12),(174,3,'Exercício 1',12),(175,3,'Exercício 2',12),(176,3,'Exercício 3',12),(177,3,'Exercício 4',12),(178,4,'Teste de Satisfação 1',12),(179,4,'Teste de Satisfação 2',12),(180,5,'Teste Final',12),(181,1,'Aula 1',13),(182,1,'Aula 2',13),(183,1,'Aula 3',13),(184,1,'Aula 4',13),(185,1,'Aula 5',13),(186,2,'Leitura 1',13),(187,2,'Leitura 2',13),(188,2,'Leitura 3',13),(189,3,'Exercício 1',13),(190,3,'Exercício 2',13),(191,3,'Exercício 3',13),(192,3,'Exercício 4',13),(193,4,'Teste de Satisfação 1',13),(194,4,'Teste de Satisfação 2',13),(195,5,'Teste Final',13),(196,1,'Aula 1',14),(197,1,'Aula 2',14),(198,1,'Aula 3',14),(199,1,'Aula 4',14),(200,1,'Aula 5',14),(201,2,'Leitura 1',14),(202,2,'Leitura 2',14),(203,2,'Leitura 3',14),(204,3,'Exercício 1',14),(205,3,'Exercício 2',14),(206,3,'Exercício 3',14),(207,3,'Exercício 4',14),(208,4,'Teste de Satisfação 1',14),(209,4,'Teste de Satisfação 2',14),(210,5,'Teste Final',14);
/*!40000 ALTER TABLE `conteudo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `curso`
--

DROP TABLE IF EXISTS `curso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `curso` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `preco` double NOT NULL,
  `desenvolvedor_id` int(11) NOT NULL,
  `nome` varchar(45) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_curso_desenvolvedor_idx` (`desenvolvedor_id`),
  KEY `fk_curso_categoria1_idx` (`categoria_id`),
  CONSTRAINT `fk_curso_categoria1` FOREIGN KEY (`categoria_id`) REFERENCES `categoria` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_curso_desenvolvedor` FOREIGN KEY (`desenvolvedor_id`) REFERENCES `administrador` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `curso`
--

LOCK TABLES `curso` WRITE;
/*!40000 ALTER TABLE `curso` DISABLE KEYS */;
INSERT INTO `curso` VALUES (1,1200,1,'Java',1),(2,1400,2,'PHP',1),(3,945,3,'Ruby',1),(4,850,1,'C#',1),(5,400,1,'Como Criar Canal no Youtube',2),(6,500,2,'Como Comprar no Exterior',2),(7,300,3,'Como Organizar um Evento',2),(8,100,2,'Como se Comportar em uma Entrevista',2),(9,120,3,'Ferramentas p/ se Tornar Mais Produtivo',2),(10,2000,1,'Inglês',3),(11,1800,2,'Chinês',3),(12,800,3,'Espanhol',3),(13,2300,3,'Alemão',3),(14,1600,1,'Japonês',3);
/*!40000 ALTER TABLE `curso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matricula`
--

DROP TABLE IF EXISTS `matricula`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matricula` (
  `aluno_id` int(11) NOT NULL,
  `curso_id` int(11) NOT NULL,
  `data_matricula` date NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `data_limite` date NOT NULL,
  PRIMARY KEY (`id`,`aluno_id`,`curso_id`),
  KEY `fk_aluno_has_curso_curso1_idx` (`curso_id`),
  KEY `fk_aluno_has_curso_aluno1_idx` (`aluno_id`)
) ENGINE=MyISAM AUTO_INCREMENT=121 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matricula`
--

LOCK TABLES `matricula` WRITE;
/*!40000 ALTER TABLE `matricula` DISABLE KEYS */;
INSERT INTO `matricula` VALUES (36,10,'2014-06-21',1,0,'2014-12-21'),(17,9,'2015-02-06',2,1,'2015-08-06'),(18,11,'2013-07-20',3,1,'2014-01-20'),(36,1,'2010-09-16',4,0,'2011-03-16'),(83,9,'2008-05-18',5,1,'2008-11-18'),(4,9,'2007-08-09',6,0,'2008-02-09'),(17,14,'2012-10-17',7,1,'2013-04-17'),(10,8,'2006-01-19',8,0,'2006-07-19'),(52,13,'2006-04-20',9,1,'2006-10-20'),(46,9,'2015-07-17',10,1,'2016-01-17'),(62,3,'2006-05-06',11,0,'2006-11-06'),(30,2,'2014-04-18',12,0,'2014-10-18'),(49,11,'2008-01-15',13,0,'2008-07-15'),(22,12,'2014-09-17',14,1,'2015-03-17'),(40,6,'2007-01-04',15,1,'2007-07-04'),(61,10,'2012-05-08',16,1,'2012-11-08'),(73,2,'2011-12-18',17,0,'2012-06-18'),(83,8,'2009-11-15',18,0,'2010-05-15'),(42,6,'2006-03-27',19,0,'2006-09-27'),(59,5,'2007-06-10',20,0,'2007-12-10'),(13,13,'2009-08-02',21,0,'2010-02-02'),(29,5,'2009-09-21',22,0,'2010-03-21'),(55,5,'2010-10-28',23,0,'2011-04-28'),(18,4,'2008-08-12',24,0,'2009-02-12'),(23,5,'2013-04-23',25,1,'2013-10-23'),(79,7,'2012-02-18',26,1,'2012-08-18'),(83,11,'2008-07-27',27,1,'2009-01-27'),(14,13,'2012-11-02',28,1,'2013-05-02'),(85,1,'2007-04-09',29,0,'2007-10-09'),(87,13,'2015-11-07',30,1,'2016-05-07'),(41,5,'2006-08-14',31,0,'2007-02-14'),(6,5,'2010-07-24',32,1,'2011-01-24'),(85,3,'2014-05-21',33,0,'2014-11-21'),(51,5,'2007-08-13',34,1,'2008-02-13'),(72,11,'2008-12-20',35,0,'2009-06-20'),(23,13,'2013-02-26',36,0,'2013-08-26'),(51,1,'2009-09-02',37,0,'2010-03-02'),(17,10,'2012-02-17',38,1,'2012-08-17'),(13,10,'2008-02-08',39,1,'2008-08-08'),(20,6,'2013-10-17',40,1,'2014-04-17'),(48,5,'2008-10-16',41,1,'2009-04-16'),(51,8,'2008-10-25',42,0,'2009-04-25'),(40,11,'2012-06-18',43,0,'2012-12-18'),(19,3,'2009-10-20',44,0,'2010-04-20'),(86,7,'2013-03-12',45,0,'2013-09-12'),(36,6,'2015-08-24',46,0,'2016-02-24'),(88,5,'2011-11-17',47,0,'2012-05-17'),(14,6,'2014-05-28',48,0,'2014-11-28'),(77,7,'2014-08-03',49,0,'2015-02-03'),(86,3,'2011-04-25',50,0,'2011-10-25'),(57,8,'2012-05-24',51,1,'2012-11-24'),(78,5,'2015-11-11',52,1,'2016-05-11'),(52,3,'2012-01-10',53,1,'2012-07-10'),(72,1,'2013-07-13',54,0,'2014-01-13'),(68,7,'2012-11-09',55,0,'2013-05-09'),(55,3,'2012-12-25',56,1,'2013-06-25'),(21,2,'2011-04-13',57,0,'2011-10-13'),(85,11,'2013-07-15',58,1,'2014-01-15'),(81,3,'2006-02-07',59,1,'2006-08-07'),(57,5,'2012-11-18',60,1,'2013-05-18'),(2,12,'2008-08-01',61,0,'2009-02-01'),(54,13,'2014-10-21',62,1,'2015-04-21'),(81,7,'2009-04-26',63,1,'2009-10-26'),(41,10,'2013-06-09',64,1,'2013-12-09'),(7,3,'2010-07-12',65,1,'2011-01-12'),(8,10,'2013-09-21',66,0,'2014-03-21'),(19,11,'2015-02-19',67,1,'2015-08-19'),(25,3,'2014-08-14',68,1,'2015-02-14'),(65,14,'2013-11-03',69,1,'2014-05-03'),(19,1,'2006-09-22',70,1,'2007-03-22'),(50,9,'2007-12-27',71,0,'2008-06-27'),(80,5,'2009-12-15',72,1,'2010-06-15'),(74,12,'2012-12-14',73,1,'2013-06-14'),(34,2,'2011-07-01',74,1,'2012-01-01'),(59,1,'2008-05-03',75,0,'2008-11-03'),(82,9,'2014-08-01',76,1,'2015-02-01'),(58,13,'2014-02-15',77,1,'2014-08-15'),(60,3,'2006-01-16',78,1,'2006-07-16'),(46,12,'2011-05-22',79,1,'2011-11-22'),(44,6,'2010-05-21',80,1,'2010-11-21'),(34,12,'2007-03-06',81,1,'2007-09-06'),(59,13,'2010-04-25',82,0,'2010-10-25'),(44,12,'2006-06-09',83,0,'2006-12-09'),(83,7,'2013-07-21',84,1,'2014-01-21'),(90,8,'2009-10-10',85,1,'2010-04-10'),(80,10,'2006-07-21',86,1,'2007-01-21'),(12,5,'2007-06-08',87,0,'2007-12-08'),(34,1,'2014-05-24',88,0,'2014-11-24'),(56,7,'2015-08-24',89,1,'2016-02-24'),(71,8,'2012-08-17',90,1,'2013-02-17'),(29,12,'2006-12-23',91,0,'2007-06-23'),(9,11,'2014-09-09',92,0,'2015-03-09'),(82,1,'2014-03-18',93,0,'2014-09-18'),(1,14,'2007-09-09',94,1,'2008-03-09'),(64,11,'2011-04-18',95,1,'2011-10-18'),(22,14,'2014-03-24',96,1,'2014-09-24'),(77,8,'2015-02-28',97,1,'2015-08-28'),(17,7,'2014-11-13',98,1,'2015-05-13'),(23,1,'2006-09-19',99,1,'2007-03-19'),(32,14,'2011-05-26',100,1,'2011-11-26'),(60,2,'2009-05-13',101,0,'2009-11-13'),(33,5,'2008-02-28',102,1,'2008-08-28'),(77,13,'2009-02-16',103,1,'2009-08-16'),(52,9,'2014-07-20',104,1,'2015-01-20'),(56,14,'2007-05-24',105,1,'2007-11-24'),(6,14,'2013-06-18',106,0,'2013-12-18'),(67,7,'2006-04-05',107,1,'2006-10-05'),(84,8,'2012-01-09',108,1,'2012-07-09'),(73,12,'2010-11-25',109,1,'2011-05-25'),(29,8,'2011-10-17',110,1,'2012-04-17'),(7,5,'2008-09-17',111,0,'2009-03-17'),(76,3,'2010-07-18',112,1,'2011-01-18'),(59,6,'2006-10-12',113,1,'2007-04-12'),(81,9,'2013-10-04',114,1,'2014-04-04'),(81,11,'2009-12-25',115,1,'2010-06-25'),(53,12,'2013-06-02',116,0,'2013-12-02'),(37,12,'2007-06-11',117,0,'2007-12-11'),(36,13,'2010-10-11',118,1,'2011-04-11'),(27,7,'2014-11-25',119,0,'2015-05-25'),(40,12,'2006-01-22',120,0,'2006-07-22');
/*!40000 ALTER TABLE `matricula` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `retorno`
--

DROP TABLE IF EXISTS `retorno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `retorno` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `texto` varchar(45) NOT NULL,
  `data` date NOT NULL,
  `qualificacao` tinyint(1) DEFAULT NULL,
  `aluno_id` int(11) NOT NULL,
  `conteudo_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_retorno_aluno1_idx` (`aluno_id`),
  KEY `fk_retorno_conteudo1_idx` (`conteudo_id`),
  CONSTRAINT `fk_retorno_aluno1` FOREIGN KEY (`aluno_id`) REFERENCES `aluno` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_retorno_conteudo1` FOREIGN KEY (`conteudo_id`) REFERENCES `conteudo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `retorno`
--

LOCK TABLES `retorno` WRITE;
/*!40000 ALTER TABLE `retorno` DISABLE KEYS */;
/*!40000 ALTER TABLE `retorno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo`
--

DROP TABLE IF EXISTS `tipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo`
--

LOCK TABLES `tipo` WRITE;
/*!40000 ALTER TABLE `tipo` DISABLE KEYS */;
INSERT INTO `tipo` VALUES (1,'Vídeo Aula'),(2,'Texto'),(3,'Exercício'),(4,'Teste de Satisfação'),(5,'Teste Final');
/*!40000 ALTER TABLE `tipo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'mydb'
--

--
-- Dumping routines for database 'mydb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-06-01 11:26:59
