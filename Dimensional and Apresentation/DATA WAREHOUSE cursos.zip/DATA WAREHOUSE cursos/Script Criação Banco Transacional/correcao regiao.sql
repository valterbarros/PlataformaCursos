SELECT COUNT(nome), estado
FROM aluno
GROUP BY estado;


UPDATE aluno SET	estado = "PE"	,cidade = "Recife"				WHERE id = 1;
UPDATE aluno SET	estado = "AL"	,cidade = "Maceió"				WHERE id = 2;
UPDATE aluno SET	estado = "AL"	,cidade = "Arapiraca"			WHERE id = 3;
UPDATE aluno SET	estado = "AC"	,cidade = "Rio Branco"			WHERE id = 4;
UPDATE aluno SET	estado = "PE"	,cidade = "Cabrobó"				WHERE id = 5;
UPDATE aluno SET	estado = "SP"	,cidade = "São Paulo"			WHERE id = 6;
UPDATE aluno SET	estado = "RJ"	,cidade = "Rio de Janeiro"		WHERE id = 7;
UPDATE aluno SET	estado = "RJ"	,cidade = "Porto Real"			WHERE id = 8;
UPDATE aluno SET	estado = "RJ"	,cidade = "Macaé"				WHERE id = 9;
UPDATE aluno SET	estado = "SP"	,cidade = "Guarulhos"			WHERE id = 10;

UPDATE aluno SET	estado = "PE"	,cidade = "Recife"				WHERE id = 11;
UPDATE aluno SET	estado = "AL"	,cidade = "Maceió"				WHERE id = 12;
UPDATE aluno SET	estado = "AL"	,cidade = "Arapiraca"			WHERE id = 13;
UPDATE aluno SET	estado = "AC"	,cidade = "Rio Branco"			WHERE id = 14;
UPDATE aluno SET	estado = "PE"	,cidade = "Cabrobó"				WHERE id = 15;
UPDATE aluno SET	estado = "SP"	,cidade = "São Paulo"			WHERE id = 16;
UPDATE aluno SET	estado = "RJ"	,cidade = "Rio de Janeiro"		WHERE id = 17;
UPDATE aluno SET	estado = "RJ"	,cidade = "Porto Real"			WHERE id = 18;
UPDATE aluno SET	estado = "RJ"	,cidade = "Macaé"				WHERE id = 19;
UPDATE aluno SET	estado = "SP"	,cidade = "Guarulhos"			WHERE id = 20;

UPDATE aluno SET	estado = "PE"	,cidade = "Recife"				WHERE id = 21;
UPDATE aluno SET	estado = "AL"	,cidade = "Maceió"				WHERE id = 22;
UPDATE aluno SET	estado = "AL"	,cidade = "Arapiraca"			WHERE id = 23;
UPDATE aluno SET	estado = "AC"	,cidade = "Rio Branco"			WHERE id = 24;
UPDATE aluno SET	estado = "PE"	,cidade = "Cabrobó"				WHERE id = 25;
UPDATE aluno SET	estado = "SP"	,cidade = "São Paulo"			WHERE id = 26;
UPDATE aluno SET	estado = "RJ"	,cidade = "Rio de Janeiro"		WHERE id = 27;
UPDATE aluno SET	estado = "RJ"	,cidade = "Porto Real"			WHERE id = 28;
UPDATE aluno SET	estado = "RJ"	,cidade = "Macaé"				WHERE id = 29;
UPDATE aluno SET	estado = "SP"	,cidade = "Guarulhos"			WHERE id = 30;

UPDATE aluno SET	estado = "PE"	,cidade = "Recife"				WHERE id = 31;
UPDATE aluno SET	estado = "AL"	,cidade = "Maceió"				WHERE id = 32;
UPDATE aluno SET	estado = "AL"	,cidade = "Arapiraca"			WHERE id = 33;
UPDATE aluno SET	estado = "AC"	,cidade = "Rio Branco"			WHERE id = 34;
UPDATE aluno SET	estado = "PE"	,cidade = "Cabrobó"				WHERE id = 35;
UPDATE aluno SET	estado = "SP"	,cidade = "São Paulo"			WHERE id = 36;
UPDATE aluno SET	estado = "RJ"	,cidade = "Rio de Janeiro"		WHERE id = 37;
UPDATE aluno SET	estado = "RJ"	,cidade = "Porto Real"			WHERE id = 38;
UPDATE aluno SET	estado = "RJ"	,cidade = "Macaé"				WHERE id = 39;
UPDATE aluno SET	estado = "SP"	,cidade = "Guarulhos"			WHERE id = 40;

UPDATE aluno SET	estado = "PE"	,cidade = "Recife"				WHERE id = 41;
UPDATE aluno SET	estado = "AL"	,cidade = "Maceió"				WHERE id = 42;
UPDATE aluno SET	estado = "AL"	,cidade = "Arapiraca"			WHERE id = 43;
UPDATE aluno SET	estado = "AC"	,cidade = "Rio Branco"			WHERE id = 44;
UPDATE aluno SET	estado = "PE"	,cidade = "Cabrobó"				WHERE id = 45;
UPDATE aluno SET	estado = "SP"	,cidade = "São Paulo"			WHERE id = 46;
UPDATE aluno SET	estado = "RJ"	,cidade = "Rio de Janeiro"		WHERE id = 47;
UPDATE aluno SET	estado = "RJ"	,cidade = "Porto Real"			WHERE id = 48;
UPDATE aluno SET	estado = "RJ"	,cidade = "Macaé"				WHERE id = 49;
UPDATE aluno SET	estado = "SP"	,cidade = "Guarulhos"			WHERE id = 50;

UPDATE aluno SET	estado = "PE"	,cidade = "Recife"				WHERE id = 51;
UPDATE aluno SET	estado = "AL"	,cidade = "Maceió"				WHERE id = 52;
UPDATE aluno SET	estado = "AL"	,cidade = "Arapiraca"			WHERE id = 53;
UPDATE aluno SET	estado = "AC"	,cidade = "Rio Branco"			WHERE id = 54;
UPDATE aluno SET	estado = "PE"	,cidade = "Cabrobó"				WHERE id = 55;
UPDATE aluno SET	estado = "SP"	,cidade = "São Paulo"			WHERE id = 56;
UPDATE aluno SET	estado = "RJ"	,cidade = "Rio de Janeiro"		WHERE id = 57;
UPDATE aluno SET	estado = "RJ"	,cidade = "Porto Real"			WHERE id = 58;
UPDATE aluno SET	estado = "RJ"	,cidade = "Macaé"				WHERE id = 59;
UPDATE aluno SET	estado = "SP"	,cidade = "Guarulhos"			WHERE id = 60;

UPDATE aluno SET	estado = "PE"	,cidade = "Recife"				WHERE id = 61;
UPDATE aluno SET	estado = "AL"	,cidade = "Maceió"				WHERE id = 62;
UPDATE aluno SET	estado = "AL"	,cidade = "Arapiraca"			WHERE id = 63;
UPDATE aluno SET	estado = "AC"	,cidade = "Rio Branco"			WHERE id = 64;
UPDATE aluno SET	estado = "PE"	,cidade = "Cabrobó"				WHERE id = 65;
UPDATE aluno SET	estado = "SP"	,cidade = "São Paulo"			WHERE id = 66;
UPDATE aluno SET	estado = "RJ"	,cidade = "Rio de Janeiro"		WHERE id = 67;
UPDATE aluno SET	estado = "RJ"	,cidade = "Porto Real"			WHERE id = 68;
UPDATE aluno SET	estado = "RJ"	,cidade = "Macaé"				WHERE id = 69;
UPDATE aluno SET	estado = "SP"	,cidade = "Guarulhos"			WHERE id = 70;

UPDATE aluno SET	estado = "PE"	,cidade = "Recife"				WHERE id = 71;
UPDATE aluno SET	estado = "AL"	,cidade = "Maceió"				WHERE id = 72;
UPDATE aluno SET	estado = "AL"	,cidade = "Arapiraca"			WHERE id = 73;
UPDATE aluno SET	estado = "AC"	,cidade = "Rio Branco"			WHERE id = 74;
UPDATE aluno SET	estado = "PE"	,cidade = "Cabrobó"				WHERE id = 75;
UPDATE aluno SET	estado = "SP"	,cidade = "São Paulo"			WHERE id = 76;
UPDATE aluno SET	estado = "RJ"	,cidade = "Rio de Janeiro"		WHERE id = 77;
UPDATE aluno SET	estado = "RJ"	,cidade = "Porto Real"			WHERE id = 78;
UPDATE aluno SET	estado = "RJ"	,cidade = "Macaé"				WHERE id = 79;
UPDATE aluno SET	estado = "SP"	,cidade = "Guarulhos"			WHERE id = 80;

UPDATE aluno SET	estado = "PE"	,cidade = "Recife"				WHERE id = 81;
UPDATE aluno SET	estado = "AL"	,cidade = "Maceió"				WHERE id = 82;
UPDATE aluno SET	estado = "AL"	,cidade = "Arapiraca"			WHERE id = 83;
UPDATE aluno SET	estado = "AC"	,cidade = "Rio Branco"			WHERE id = 84;
UPDATE aluno SET	estado = "PE"	,cidade = "Cabrobó"				WHERE id = 85;
UPDATE aluno SET	estado = "SP"	,cidade = "São Paulo"			WHERE id = 86;
UPDATE aluno SET	estado = "RJ"	,cidade = "Rio de Janeiro"		WHERE id = 87;
UPDATE aluno SET	estado = "RJ"	,cidade = "Porto Real"			WHERE id = 88;
UPDATE aluno SET	estado = "RJ"	,cidade = "Macaé"				WHERE id = 89;
UPDATE aluno SET	estado = "SP"	,cidade = "Guarulhos"			WHERE id = 90;