-- ALUNO - 100
INSERT INTO `aluno` (`nome`,`login`,`senha`,`carteira`,`cidade`,`estado`,`data_nascimento`) VALUES ("Eric Mercer","Wyoming","LTZ18UOB3KX",108,"Carcassonne","II","1949-02-18 22:57:28"),("Jarrod Mccarthy","Selma","SYV28GPH0ZA",17,"Cajazeiras","HI","1982-09-16 08:38:35"),("Rigel Farley","Karly","INI82JYX5LD",82,"Florenville","VU","1971-03-05 23:30:32"),("Jaquelyn Levine","Florence","AHR12FOO6AI",99,"Fossato Serralta","AM","1985-02-16 18:05:31"),("Sophia Mathis","Deanna","XDR10LRP0FO",49,"Medicine Hat","JR","1960-02-28 14:52:55"),("Ali Henderson","Benjamin","RDN01IYX9NF",1,"Massenhoven","HE","1950-06-02 16:10:43"),("Aiko Ferguson","Slade","JFU98XNK5DO",90,"Peine","UH","1986-10-16 17:02:03"),("Aubrey Dalton","Uma","CHE37DCX3JC",60,"Sundrie","GK","2001-12-07 15:33:54"),("Melanie Barnes","Adara","LSX12SNM1CY",101,"Marchienne-au-Pont","LS","2006-07-30 18:52:53"),("Eaton Wilcox","Iona","NQT52IBG5MO",2,"Valmacca","LO","1969-10-13 21:42:21");
INSERT INTO `aluno` (`nome`,`login`,`senha`,`carteira`,`cidade`,`estado`,`data_nascimento`) VALUES ("Thor Stephens","Germaine","MOG37IXR9RT",10,"Kirriemuir","US","1985-01-09 21:36:07"),("Tamekah Miranda","Regan","FAB37NEC9XI",85,"Joliet","AK","1950-08-10 08:57:37"),("Perry Trujillo","Bree","HHQ12WAD7PK",70,"São João de Meriti","WG","1974-10-01 21:25:25"),("Raja Medina","Mechelle","XGW02APU5TT",105,"Chiaromonte","GP","2004-09-13 19:16:22"),("Jada Hays","Gil","UFP48RCF3FV",108,"Campotosto","AV","1974-02-11 20:41:26"),("Amy Conway","Yuli","NDN07IHW7GL",12,"Darbhanga","CX","1967-01-17 06:15:56"),("Cheyenne Mitchell","Jack","MAH56EBL8PL",105,"Getafe","CT","1989-07-05 20:29:25"),("Jillian Giles","Haley","JAF52YCY2NW",19,"Saint-Étienne-du-Rouvray","CG","1998-01-07 04:30:10"),("Jonah Lucas","Skyler","SFA35ONL0EN",79,"Straubing","FU","1979-07-14 07:09:11"),("Beck Barton","Cody","MIK33GSV6FE",17,"Richmond","KD","1983-11-10 03:37:33");
INSERT INTO `aluno` (`nome`,`login`,`senha`,`carteira`,`cidade`,`estado`,`data_nascimento`) VALUES ("Dahlia Estes","Erasmus","PXT10TXA1MJ",95,"King Township","JM","1997-08-03 07:15:59"),("Jonas Mcpherson","Kennedy","DKH51KDB6IP",71,"Cajazeiras","YH","1958-12-08 13:42:59"),("Meghan Bullock","Brady","XZI61DSO5LF",27,"Salzburg","MS","1987-10-10 18:55:25"),("Basia Rivera","Wing","DKA81IBE4CU",14,"Freux","ZG","2003-01-12 04:55:40"),("Gage Sanford","Griffin","BQP98EPN6YA",53,"Codó","CJ","1952-12-05 00:58:01"),("Madison Cantu","Ingrid","GFN30MHR7FZ",54,"Judenburg","GQ","1961-06-19 07:30:35"),("Nissim Todd","Logan","KWH44NCS2HN",85,"Mores","ZA","1947-12-27 23:29:56"),("Darryl Cabrera","Colton","HYJ85RJF4FW",43,"Lacombe County","MR","1971-03-20 18:52:11"),("Quinn Brock","Laura","HJQ66FVS9LN",61,"Jamioulx","GG","2001-05-01 12:40:46"),("Joan Ballard","Angelica","NRS10FOS7YF",102,"Dieppe","ZI","1978-08-04 02:07:09");
INSERT INTO `aluno` (`nome`,`login`,`senha`,`carteira`,`cidade`,`estado`,`data_nascimento`) VALUES ("Sydnee Chapman","Audra","JHZ29XVD7ZZ",56,"Baden","PW","1973-01-25 11:37:22"),("Derek Langley","Bert","AMJ09VIP9PA",4,"Limal","TY","2001-03-29 15:46:34"),("Neil Newton","Aurora","IEN29XXB9PA",116,"Juneau","BD","1994-02-22 10:26:52"),("Jana Hess","Quemby","NHN94KXM0MU",83,"Termes","ZW","1994-01-07 03:53:35"),("Leslie Forbes","Jenna","LEX55MSV6WL",93,"Glendon","WZ","2004-05-19 02:00:27"),("Velma Fox","Fredericka","TLR28HID5YG",68,"Hafizabad","DL","1969-08-20 09:09:04"),("Audra Gibson","Blake","LYE01UFQ3HG",72,"Tulita","LP","1966-03-11 16:09:42"),("Dakota Vaughn","Nero","KQD20AOJ7AS",102,"Poole","MC","2006-09-19 08:35:02"),("Pearl Stone","Martena","HWB90TOA3NN",26,"Bon Accord","OT","2002-10-31 04:38:21"),("Damon Branch","Aristotle","RCJ13INQ3RS",73,"Perk","SP","1949-09-15 09:01:02");
INSERT INTO `aluno` (`nome`,`login`,`senha`,`carteira`,`cidade`,`estado`,`data_nascimento`) VALUES ("Kiara Wolfe","Farrah","CWY80VMN1ZA",87,"Telford","XP","1946-11-26 15:27:47"),("Grady Hart","Rajah","MPW07JLS1GV",109,"Sedgewick","DS","1948-06-23 15:59:30"),("Garth Velazquez","Charles","SBD24RPP3LF",108,"Doetinchem","QF","2006-07-04 03:27:29"),("Nicholas Turner","Kristen","ACK36KPD3QW",67,"Wilmont","WT","1988-06-05 13:42:01"),("Emery Joyner","Sylvia","SAJ32SFI6UU",58,"Gjoa Haven","XY","1974-05-28 06:37:26"),("Michelle Gay","Hoyt","BDN56WNI5KI",59,"Chaudfontaine","EX","1971-08-15 07:31:21"),("Wallace Allison","Lacota","LIW73VOU3MW",119,"Oteppe","UI","1993-05-22 15:57:32"),("Wyoming Flores","Carl","OGD81HTX3OV",85,"Bragança","NT","1991-11-23 15:12:10"),("Kuame Albert","Sylvia","SIL83SKD2PZ",26,"Avignon","VW","2008-06-30 06:11:09"),("Sawyer Mcintyre","Gwendolyn","JHX76DMN8BH",68,"New Westminster","EY","2008-07-15 22:51:09");
INSERT INTO `aluno` (`nome`,`login`,`senha`,`carteira`,`cidade`,`estado`,`data_nascimento`) VALUES ("Norman Cooper","Deborah","AJJ75VIA6UB",72,"Stewart","AD","2001-05-01 00:47:34"),("Felicia Riddle","Hasad","BXY30TMU1UE",6,"Elen","SM","1945-08-19 09:23:38"),("Dominic Anderson","Mira","YOI16LDE6RC",32,"Dorchester","UA","1949-10-31 10:52:32"),("Frances Webb","Wade","ZKL58LPJ7ML",10,"Renfrew","XT","1948-09-06 14:31:52"),("Tobias Robertson","Reece","HIN18EYW2NZ",22,"Owen Sound","GT","1982-12-21 20:45:57"),("Brenna Joyce","Doris","ERS18WSY6QK",34,"Wasseiges","NG","1945-12-25 05:48:30"),("Rana Slater","Tarik","YUT20ETB2DU",14,"Cittanova","FJ","1959-09-13 05:41:46"),("Orli Kelley","Mohammad","RJC92BFH7KE",102,"Angoulême","ZT","1948-09-16 10:29:12"),("Wing Mcdaniel","Michelle","UMI38HLX0NA",111,"Varanasi","WA","1983-07-25 18:59:23"),("Gwendolyn Larson","Zephr","XAB11LCA0PP",43,"Glendale","PV","2006-08-25 12:59:27");
INSERT INTO `aluno` (`nome`,`login`,`senha`,`carteira`,`cidade`,`estado`,`data_nascimento`) VALUES ("Iona Leon","Erich","HSO42IRD3QT",24,"New Sarepta","ME","1963-05-02 02:28:30"),("Vera Dale","Hiroko","LJW27GPK1BB",34,"Heikruis","HR","1972-01-28 22:07:47"),("Yetta Mcclure","Jack","EYM01TVV0TO",101,"Abbotsford","BX","2008-07-04 11:37:39"),("Amos Wolf","May","LBO03BQK8RQ",87,"Kessel","PK","1987-09-18 18:51:40"),("Ezra Hyde","Zia","GFN22BSV2IR",107,"Port Glasgow","XH","1990-10-20 00:22:48"),("Ivory Howe","Beau","AYB51CUK7UR",49,"Sedgewick","GI","1978-03-26 11:44:37"),("Alfonso Anthony","Mollie","RQL47ZIY2OT",86,"Alviano","QR","1981-05-25 17:17:12"),("Amena Mason","Bevis","CJU31KUA3VG",51,"Fort Good Hope","EZ","1984-11-21 03:20:32"),("Cheyenne Smith","Colleen","GDA81BJF7YB",63,"Pieve di Cadore","SO","1976-05-13 15:08:26"),("Cain Stevenson","Kellie","CVK88KRF7BT",90,"Desteldonk","BZ","1997-09-11 22:44:32");
INSERT INTO `aluno` (`nome`,`login`,`senha`,`carteira`,`cidade`,`estado`,`data_nascimento`) VALUES ("Oliver Bolton","Colby","XQZ16NUO6FJ",63,"Toronto","SD","1986-08-25 20:16:53"),("Erin Newton","Howard","KDF88AIJ4BO",84,"Saguenay","KR","1975-07-10 21:02:51"),("Slade Dudley","Leigh","ITB89QRO1KT",89,"Colomiers","OE","1968-06-09 13:45:07"),("Phillip Vasquez","Branden","VEH33JEF8RY",48,"Tranås","LV","1950-10-17 20:29:54"),("Perry Martin","Veda","YFJ24GFZ9TQ",36,"Galway","WH","1994-08-13 15:18:03"),("Chaney Murray","Ciara","SRI28RZM4UO",1,"Martigues","YW","1969-06-16 18:50:34"),("Perry Carlson","Aspen","TFG38CZW3CL",42,"Yumbel","XO","1958-12-02 14:15:13"),("Nevada Mcmahon","Courtney","DJQ50COA7UK",115,"Traun","ZN","1947-03-30 19:13:26"),("Kirsten Estes","Althea","GGS14RMX7TA",30,"Bersillies-lAbbaye","YK","1999-12-27 17:04:44"),("Magee Landry","Karleigh","AKY42TJN9ZY",33,"Dandenong","MW","1983-08-30 17:52:36");
INSERT INTO `aluno` (`nome`,`login`,`senha`,`carteira`,`cidade`,`estado`,`data_nascimento`) VALUES ("Savannah Peck","Kareem","VYJ99SID8KZ",78,"Greenlaw","KS","1950-04-13 17:15:10"),("Adam Willis","Imelda","WKP65LBB3SG",9,"Meerdonk","CZ","1972-06-25 07:10:00"),("Amanda Dixon","Bertha","VYE08ADD3PW",74,"Taunton","XZ","1959-07-26 03:29:44"),("Oleg Cain","Carl","XQJ80BDG1KS",64,"Wollongong","HS","1954-06-25 14:58:47"),("Leilani Rasmussen","Randall","BHS11TDR5PT",18,"Blind River","MM","2001-05-01 14:33:20"),("Ava Yang","Regina","HJS70TEZ3ZQ",47,"Montese","OD","1967-11-02 00:58:30"),("Willa Rogers","Amena","AUF55ZCZ2DB",28,"Neyveli","KI","1996-10-28 11:08:27"),("Jacob Weiss","Uriah","VKU70QUH9YX",78,"Bonavista","SD","1989-02-13 08:17:28"),("Avram Carter","David","OAO61DSZ7JZ",24,"Miramichi","SO","1994-12-23 10:43:49"),("Kirsten Leblanc","Gabriel","HBP04GJG2RJ",104,"Aylmer","BG","1946-03-30 11:12:42");
select * from aluno;

-- ADMINISTRADOR - 3
INSERT INTO administrador (login, senha) 
VALUES 
	("paulo", "123456"),
	("jones", "123456"),
	("valter", "123456");


-- CATEGORIA - 3
INSERT INTO categoria (nome)
VALUES
	("Programação"),
	("Utilidade Pública"),
	("Idioma");


-- TIPO - 5
INSERT INTO tipo (nome) VALUES ("Vídeo Aula");
INSERT INTO tipo (nome) VALUES ("Texto");
INSERT INTO tipo (nome) VALUES ("Exercício");
INSERT INTO tipo (nome) VALUES ("Teste de Satisfação");
INSERT INTO tipo (nome) VALUES ("Teste Final");


-- CURSOS
-- Programação - 4
INSERT INTO curso (preco, desenvolvedor_id, nome, categoria_id) 
VALUES
	(1200, 1, "Java", 1),
	(1400, 2, "PHP", 1),
	(945, 3, "Ruby", 1),
	(850, 1, "C#", 1);
-- Utilidade Pública - 5
INSERT INTO curso (preco, desenvolvedor_id, nome, categoria_id) 
VALUES 
	(400, 1,"Como Criar Canal no Youtube" ,2),
	(500, 2,"Como Comprar no Exterior" ,2),
	(300, 3,"Como Organizar um Evento" ,2),
	(100, 2,"Como se Comportar em uma Entrevista" ,2),
	(120, 3,"Ferramentas p/ se Tornar Mais Produtivo" ,2);
-- Idioma - 5
INSERT INTO curso (preco, desenvolvedor_id, nome, categoria_id) 
VALUES 
	(2000, 1,"Inglês" ,3),
	(1800, 2,"Chinês" ,3),
	(800, 3,"Espanhol" ,3),
	(2300, 3,"Alemão" ,3),
	(1600, 1,"Japonês" ,3);


-- CONTEÚDO - 210
-- Curso 1 - Java
INSERT INTO conteudo (tipo_id, conteudo, curso_id)
VALUES
	(1, "Aula 1", 1), (1, "Aula 2", 1), (1, "Aula 3", 1), (1, "Aula 4", 1), (1, "Aula 5", 1),
	(2, "Leitura 1", 1), (2, "Leitura 2", 1), (2, "Leitura 3", 1),
	(3, "Exercício 1", 1), (3, "Exercício 2", 1), (3, "Exercício 3", 1), (3, "Exercício 4", 1),
	(4, "Teste de Satisfação 1", 1), (4, "Teste de Satisfação 2", 1),
	(5, "Teste Final", 1);
-- Curso 2 - PHP
INSERT INTO conteudo (tipo_id, conteudo, curso_id)
VALUES
	(1, "Aula 1", 2), (1, "Aula 2", 2), (1, "Aula 3", 2), (1, "Aula 4", 2), (1, "Aula 5", 2),
	(2, "Leitura 1", 2), (2, "Leitura 2", 2), (2, "Leitura 3", 2),
	(3, "Exercício 1", 2), (3, "Exercício 2", 2), (3, "Exercício 3", 2), (3, "Exercício 4", 2),
	(4, "Teste de Satisfação 1", 2), (4, "Teste de Satisfação 2", 2),
	(5, "Teste Final", 2);
-- Curso 3 - Ruby
INSERT INTO conteudo (tipo_id, conteudo, curso_id)
VALUES
	(1, "Aula 1", 3), (1, "Aula 2", 3), (1, "Aula 3", 3), (1, "Aula 4", 3), (1, "Aula 5", 3),
	(2, "Leitura 1", 3), (2, "Leitura 2", 3), (2, "Leitura 3", 3),
	(3, "Exercício 1", 3), (3, "Exercício 2", 3), (3, "Exercício 3", 3), (3, "Exercício 4", 3),
	(4, "Teste de Satisfação 1", 3), (4, "Teste de Satisfação 2", 3),
	(5, "Teste Final", 3);
-- Curso 4 - C#
INSERT INTO conteudo (tipo_id, conteudo, curso_id)
VALUES
	(1, "Aula 1", 4), (1, "Aula 2", 4), (1, "Aula 3", 4), (1, "Aula 4", 4), (1, "Aula 5", 4),
	(2, "Leitura 1", 4), (2, "Leitura 2", 4), (2, "Leitura 3", 4),
	(3, "Exercício 1", 4), (3, "Exercício 2", 4), (3, "Exercício 3", 4), (3, "Exercício 4", 4),
	(4, "Teste de Satisfação 1", 1), (4, "Teste de Satisfação 2", 4),
	(5, "Teste Final", 4);
-- Curso 5 - Como Criar Canal no Youtube
INSERT INTO conteudo (tipo_id, conteudo, curso_id)
VALUES
	(1, "Aula 1", 5), (1, "Aula 2", 5), (1, "Aula 3", 5), (1, "Aula 4", 5), (1, "Aula 5", 5),
	(2, "Leitura 1", 5), (2, "Leitura 2", 5), (2, "Leitura 3", 5),
	(3, "Exercício 1", 5), (3, "Exercício 2", 5), (3, "Exercício 3", 5), (3, "Exercício 4", 5),
	(4, "Teste de Satisfação 1", 5), (4, "Teste de Satisfação 2", 5),
	(5, "Teste Final", 5);
-- Curso 6 - Como Comprar no Exterior
INSERT INTO conteudo (tipo_id, conteudo, curso_id)
VALUES
	(1, "Aula 1", 6), (1, "Aula 2", 6), (1, "Aula 3", 6), (1, "Aula 4", 6), (1, "Aula 5", 6),
	(2, "Leitura 1", 6), (2, "Leitura 2", 6), (2, "Leitura 3", 6),
	(3, "Exercício 1", 6), (3, "Exercício 2", 6), (3, "Exercício 3", 6), (3, "Exercício 4", 6),
	(4, "Teste de Satisfação 1", 6), (4, "Teste de Satisfação 2", 6),
	(5, "Teste Final", 6);
-- Curso 7 - Como Organizar um Evento
INSERT INTO conteudo (tipo_id, conteudo, curso_id)
VALUES
	(1, "Aula 1", 7), (1, "Aula 2", 7), (1, "Aula 3", 1), (1, "Aula 4", 7), (1, "Aula 5", 7),
	(2, "Leitura 1", 7), (2, "Leitura 2", 7), (2, "Leitura 3", 7),
	(3, "Exercício 1", 7), (3, "Exercício 2", 7), (3, "Exercício 3", 7), (3, "Exercício 4", 7),
	(4, "Teste de Satisfação 1", 7), (4, "Teste de Satisfação 2", 7),
	(5, "Teste Final", 7);
-- Curso 8 - Como se Comportar em uma Entrevista
INSERT INTO conteudo (tipo_id, conteudo, curso_id)
VALUES
	(1, "Aula 1", 8), (1, "Aula 2", 8), (1, "Aula 3", 8), (1, "Aula 4", 8), (1, "Aula 5", 8),
	(2, "Leitura 1", 8), (2, "Leitura 2", 8), (2, "Leitura 3", 8),
	(3, "Exercício 1", 8), (3, "Exercício 2", 8), (3, "Exercício 3", 8), (3, "Exercício 4", 8),
	(4, "Teste de Satisfação 1", 8), (4, "Teste de Satisfação 2", 8),
	(5, "Teste Final", 8);
-- Curso 9 - Ferramentas p/ se Tornar Mais Produtivo
INSERT INTO conteudo (tipo_id, conteudo, curso_id)
VALUES
	(1, "Aula 1", 9), (1, "Aula 2", 9), (1, "Aula 3", 9), (1, "Aula 4", 9), (1, "Aula 5", 9),
	(2, "Leitura 1", 9), (2, "Leitura 2", 9), (2, "Leitura 3", 9),
	(3, "Exercício 1", 9), (3, "Exercício 2", 9), (3, "Exercício 3", 9), (3, "Exercício 4", 9),
	(4, "Teste de Satisfação 1", 9), (4, "Teste de Satisfação 2", 9),
	(5, "Teste Final", 9);
-- Curso 10 - Inglês
INSERT INTO conteudo (tipo_id, conteudo, curso_id)
VALUES
	(1, "Aula 1", 10), (1, "Aula 2", 10), (1, "Aula 3", 10), (1, "Aula 4", 10), (1, "Aula 5", 10),
	(2, "Leitura 1", 10), (2, "Leitura 2", 10), (2, "Leitura 3", 10),
	(3, "Exercício 1", 10), (3, "Exercício 2", 10), (3, "Exercício 3", 10), (3, "Exercício 4", 10),
	(4, "Teste de Satisfação 1", 10), (4, "Teste de Satisfação 2", 10),
	(5, "Teste Final", 10);
-- Curso 11 - Chinês
INSERT INTO conteudo (tipo_id, conteudo, curso_id)
VALUES
	(1, "Aula 1", 11), (1, "Aula 2", 11), (1, "Aula 3", 11), (1, "Aula 4", 11), (1, "Aula 5", 11),
	(2, "Leitura 1", 11), (2, "Leitura 2", 11), (2, "Leitura 3", 11),
	(3, "Exercício 1", 11), (3, "Exercício 2", 11), (3, "Exercício 3", 11), (3, "Exercício 4", 11),
	(4, "Teste de Satisfação 1", 11), (4, "Teste de Satisfação 2", 11),
	(5, "Teste Final", 11);
-- Curso 12 - Espanhol
INSERT INTO conteudo (tipo_id, conteudo, curso_id)
VALUES
	(1, "Aula 1", 12), (1, "Aula 2", 12), (1, "Aula 3", 12), (1, "Aula 4", 12), (1, "Aula 5", 12),
	(2, "Leitura 1", 12), (2, "Leitura 2", 12), (2, "Leitura 3", 12),
	(3, "Exercício 1", 12), (3, "Exercício 2", 12), (3, "Exercício 3", 12), (3, "Exercício 4", 12),
	(4, "Teste de Satisfação 1", 12), (4, "Teste de Satisfação 2", 12),
	(5, "Teste Final", 12);
-- Curso 13 - Alemão
INSERT INTO conteudo (tipo_id, conteudo, curso_id)
VALUES
	(1, "Aula 1", 13), (1, "Aula 2", 13), (1, "Aula 3", 13), (1, "Aula 4", 13), (1, "Aula 5", 13),
	(2, "Leitura 1", 13), (2, "Leitura 2", 13), (2, "Leitura 3", 13),
	(3, "Exercício 1", 13), (3, "Exercício 2", 13), (3, "Exercício 3", 13), (3, "Exercício 4", 13),
	(4, "Teste de Satisfação 1", 13), (4, "Teste de Satisfação 2", 13),
	(5, "Teste Final", 13);
-- Curso 14 - Japonês
INSERT INTO conteudo (tipo_id, conteudo, curso_id)
VALUES
	(1, "Aula 1", 14), (1, "Aula 2", 14), (1, "Aula 3", 14), (1, "Aula 4", 14), (1, "Aula 5", 14),
	(2, "Leitura 1", 14), (2, "Leitura 2", 14), (2, "Leitura 3", 14),
	(3, "Exercício 1", 14), (3, "Exercício 2", 14), (3, "Exercício 3", 14), (3, "Exercício 4", 14),
	(4, "Teste de Satisfação 1", 14), (4, "Teste de Satisfação 2", 14),
	(5, "Teste Final", 14);


-- MATRÍCULA - 120
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (36,10, "2014-6-21", "2014-12-21", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (17,9, "2015-2-6", "2015-8-6", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (18,11, "2013-7-20", "2014-1-20", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (36,1, "2010-9-16", "2011-3-16", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (83,9, "2008-5-18", "2008-11-18", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (4,9, "2007-8-9", "2008-2-9", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (17,14, "2012-10-17", "2013-4-17", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (10,8, "2006-1-19", "2006-7-19", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (52,13, "2006-4-20", "2006-10-20", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (46,9, "2015-7-17", "2016-1-17", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (62,3, "2006-5-6", "2006-11-6", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (30,2, "2014-4-18", "2014-10-18", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (49,11, "2008-1-15", "2008-7-15", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (22,12, "2014-9-17", "2015-3-17", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (40,11, "2007-1-4", "2007-7-4", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (61,10, "2012-5-8", "2012-11-8", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (73,2, "2011-12-18", "2012-6-18", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (83,8, "2009-11-15", "2010-5-15", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (42,6, "2006-3-27", "2006-9-27", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (59,5, "2007-6-10", "2007-12-10", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (13,13, "2009-8-2", "2010-2-2", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (29,5, "2009-9-21", "2010-3-21", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (55,5, "2010-10-28", "2011-4-28", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (18,4, "2008-8-12", "2009-2-12", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (23,5, "2013-4-23", "2013-10-23", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (79,7, "2012-2-18", "2012-8-18", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (83,11, "2008-7-27", "2009-1-27", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (14,13, "2012-11-2", "2013-5-2", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (85,1, "2007-4-9", "2007-10-9", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (87,13, "2015-11-7", "2016-5-7", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (41,10, "2006-8-14", "2007-2-14", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (6,5, "2010-7-24", "2011-1-24", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (85,1, "2014-5-21", "2014-11-21", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (51,5, "2007-8-13", "2008-2-13", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (72,11, "2008-12-20", "2009-6-20", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (23,13, "2013-2-26", "2013-8-26", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (51,8, "2009-9-2", "2010-3-2", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (17,14, "2012-2-17", "2012-8-17", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (13,10, "2008-2-8", "2008-8-8", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (20,6, "2013-10-17", "2014-4-17", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (48,5, "2008-10-16", "2009-4-16", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (51,8, "2008-10-25", "2009-4-25", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (40,11, "2012-6-18", "2012-12-18", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (19,3, "2009-10-20", "2010-4-20", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (86,7, "2013-3-12", "2013-9-12", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (36,6, "2015-8-24", "2016-2-24", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (88,5, "2011-11-17", "2012-5-17", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (14,6, "2014-5-28", "2014-11-28", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (77,7, "2014-8-3", "2015-2-3", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (86,7, "2011-4-25", "2011-10-25", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (57,8, "2012-5-24", "2012-11-24", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (78,5, "2015-11-11", "2016-5-11", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (52,3, "2012-1-10", "2012-7-10", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (72,1, "2013-7-13", "2014-1-13", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (68,7, "2012-11-9", "2013-5-9", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (55,3, "2012-12-25", "2013-6-25", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (21,2, "2011-4-13", "2011-10-13", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (85,11, "2013-7-15", "2014-1-15", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (81,3, "2006-2-7", "2006-8-7", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (57,5, "2012-11-18", "2013-5-18", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (2,12, "2008-8-1", "2009-2-1", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (54,13, "2014-10-21", "2015-4-21", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (81,7, "2009-4-26", "2009-10-26", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (41,10, "2013-6-9", "2013-12-9", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (7,3, "2010-7-12", "2011-1-12", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (8,10, "2013-9-21", "2014-3-21", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (19,1, "2015-2-19", "2015-8-19", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (25,3, "2014-8-14", "2015-2-14", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (65,14, "2013-11-3", "2014-5-3", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (19,1, "2006-9-22", "2007-3-22", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (50,9, "2007-12-27", "2008-6-27", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (80,5, "2009-12-15", "2010-6-15", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (74,12, "2012-12-14", "2013-6-14", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (34,12, "2011-7-1", "2012-1-1", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (59,1, "2008-5-3", "2008-11-3", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (82,9, "2014-8-1", "2015-2-1", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (58,13, "2014-2-15", "2014-8-15", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (60,3, "2006-1-16", "2006-7-16", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (46,12, "2011-5-22", "2011-11-22", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (44,6, "2010-5-21", "2010-11-21", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (34,12, "2007-3-6", "2007-9-6", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (59,13, "2010-4-25", "2010-10-25", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (44,12, "2006-6-9", "2006-12-9", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (83,9, "2013-7-21", "2014-1-21", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (90,8, "2009-10-10", "2010-4-10", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (80,10, "2006-7-21", "2007-1-21", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (12,5, "2007-6-8", "2007-12-8", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (34,1, "2014-5-24", "2014-11-24", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (56,7, "2015-8-24", "2016-2-24", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (71,8, "2012-8-17", "2013-2-17", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (29,12, "2006-12-23", "2007-6-23", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (9,11, "2014-9-9", "2015-3-9", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (82,1, "2014-3-18", "2014-9-18", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (1,14, "2007-9-9", "2008-3-9", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (64,11, "2011-4-18", "2011-10-18", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (22,14, "2014-3-24", "2014-9-24", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (77,8, "2015-2-28", "2015-8-28", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (17,7, "2014-11-13", "2015-5-13", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (23,1, "2006-9-19", "2007-3-19", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (32,14, "2011-5-26", "2011-11-26", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (60,2, "2009-5-13", "2009-11-13", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (33,5, "2008-2-28", "2008-8-28", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (77,13, "2009-2-16", "2009-8-16", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (52,9, "2014-7-20", "2015-1-20", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (56,14, "2007-5-24", "2007-11-24", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (6,14, "2013-6-18", "2013-12-18", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (67,7, "2006-4-5", "2006-10-5", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (84,8, "2012-1-9", "2012-7-9", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (73,12, "2010-11-25", "2011-5-25", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (29,8, "2011-10-17", "2012-4-17", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (7,5, "2008-9-17", "2009-3-17", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (76,3, "2010-7-18", "2011-1-18", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (59,6, "2006-10-12", "2007-4-12", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (81,9, "2013-10-4", "2014-4-4", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (81,11, "2009-12-25", "2010-6-25", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (53,12, "2013-6-2", "2013-12-2", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (37,12, "2007-6-11", "2007-12-11", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (36,13, "2010-10-11", "2011-4-11", 1);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (27,7, "2014-11-25", "2015-5-25", 0);
INSERT INTO matricula (aluno_id, curso_id, data_matricula, data_limite, status) VALUES (40,12, "2006-1-22", "2006-7-22", 0);