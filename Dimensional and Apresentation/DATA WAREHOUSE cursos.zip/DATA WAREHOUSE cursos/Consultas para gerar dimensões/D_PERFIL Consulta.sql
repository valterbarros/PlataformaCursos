-- Um registro por aluno
SELECT nome,
	CASE 
		WHEN (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) < 10 then '< 10'
        
		WHEN (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) >= 10
			AND (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) < 20 then '10-19'
            
		WHEN (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) >= 20
			AND (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) < 30 then '20-29'
            
		WHEN (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) >= 30
			AND (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) < 40 then '30-39'
		
        WHEN (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) >= 40
			AND (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) < 50 then '40-49'
            
		WHEN (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) >= 50
			AND (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) < 60 then '50-59'
                        
			   ELSE "> 60"
		END as FAIXA_ETARIA
FROM aluno;


-- Um registro por quantidade de faixa étaria
SELECT COUNT(id),
	CASE 
		WHEN (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) < 10 then '< 10'
        
		WHEN (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) >= 10
			AND (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) < 20 then '10-19'
            
		WHEN (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) >= 20
			AND (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) < 30 then '20-29'
            
		WHEN (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) >= 30
			AND (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) < 40 then '30-39'
		
        WHEN (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) >= 40
			AND (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) < 50 then '40-49'
            
		WHEN (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) >= 50
			AND (TIMESTAMPDIFF(YEAR, data_nascimento, CURRENT_DATE)) < 60 then '50-59'
                        
			   ELSE "> 60"
		END as FAIXA_ETARIA
FROM aluno
group by FAIXA_ETARIA;

