select matricula.id as "ID Matricula", curso_id as "ID curso",count(aluno_id) as "Quantidade de Alunos" from matricula
group by curso_id;
